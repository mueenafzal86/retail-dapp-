import Body from "@/components/Body";
import Purchase from "@/components/Purchase";
import Navbar from "@/components/Navbar";
import axios from "axios";
import Image from "next/image";

export type PRODUCT = {
  id: number;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  rating: {
    rate: number;
  }
}

export default async function page() {
  const response = await axios.get('https://fakestoreapi.com/products');
  const data = response.data;
  return (
    <div className="pt-[3rem] space-y-16 bg-gradient-to-b from-blue-400 to-blue-950">
      <Navbar/>
      <Purchase/>
      <Body data={data}/>
    </div>
  );
}
