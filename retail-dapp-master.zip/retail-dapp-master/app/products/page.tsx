import axios from "axios";
import { PRODUCT } from "../page";
import Product from "@/components/Product";
import Navbar from "@/components/Navbar";

const page = async () => {
  const response = await axios.get("https://fakestoreapi.com/products");
  const products: PRODUCT[] = response.data;

  return (
    <div className="pt-[3rem] space-y-10">
      <Navbar/>
      <div className="space-y-10 px-[7rem]">
      <p className="text-3xl font-semibold">Products</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 py-4">
        {products.map((product: PRODUCT, index: number) => (
          <Product key={index} product={product} />
        ))}
      </div>
      </div>
    </div>
  );
};

export default page;
