import { PRODUCT } from "@/app/page";
import Image from "next/image";
import React from "react";
import Product from "./Product";

const Body = ({ data }: { data: PRODUCT[] }) => {
  return (
    <div className="px-7 md:px-12 lg:px-20 xl:px-32 container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Trending Products</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {data.slice(0, 9).map((product: PRODUCT, index: number) => (
          <Product key={index} product={product} />
        ))}
      </div>
    </div>
  );
};

export default Body;
