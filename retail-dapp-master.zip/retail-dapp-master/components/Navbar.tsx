"use client"
import { client } from "../thirdweb";
import Link from "next/link";
import { ConnectButton } from "thirdweb/react"
import { createWallet, embeddedWallet } from "thirdweb/wallets";
// import { Button } from "./ui/button";

const wallets = [
    embeddedWallet(),
    createWallet("io.metamask"),
    createWallet("com.coinbase.wallet"),
    createWallet("me.rainbow"),
  ];

const Navbar = () => {
  return (
    <div className="font-mono px-[7rem]">
        <div className="flex items-center justify-between">
        <Link href="/" className="text-xl">LOGO</Link>
        <div className="font-medium space-x-24">
        <Link href="/" className="text-base">Home</Link>
        <Link href="/products" className="text-base">Products</Link>
        </div>
        <div>
        <ConnectButton client={client} wallets={wallets} />
        </div>
        </div>
    </div>
  )
}

export default Navbar