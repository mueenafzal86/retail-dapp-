"use client";
import { PRODUCT } from "@/app/page";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { prepareContractCall, resolveMethod, toEther, toWei } from "thirdweb";
import { useConnectedWallets, useSendTransaction } from "thirdweb/react";
import { contract } from "@/thirdweb";
import Image from "next/image";

const Product = ({ product }: { product: PRODUCT }) => {
  const { mutate: sendTransaction, isPending } = useSendTransaction();
  const wallets = useConnectedWallets();
  const { rate } = product.rating;
  const ETH_USD: number = 3400;
  const rating = Number(rate.toFixed(0));
  const product_price_eth = product.price / ETH_USD;
  const purchaseProduct = async () => {
    if (wallets.length === 0) {
      alert("Please connect wallet");
    } else {
      const product_price_in_wei = toWei(product_price_eth.toString());
      const transaction = prepareContractCall({
        contract,
        method: resolveMethod("purchaseProduct"),
        params: [product.id],
        value: product_price_in_wei,
      });
      const tx = sendTransaction(transaction);
      alert(
        "Product purchase successfully. Wait for the transaction confirmation."
      );
    }
  };
  return (
    <div>
      <AlertDialog>
        <AlertDialogTrigger>
          <div className="bg-white shadow-lg rounded-lg overflow-hidden">
            <Image
              src={product.image}
              alt={product.title}
              width={100}
              height={100}
              className="w-full h-40 object-cover object-center"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">
                {product.title.slice(0, 20)}
              </h2>
              <p className="text-gray-700 mb-2">
                {product.description.slice(0, 70)}
              </p>
              <p className="text-gray-900 font-bold">
                ${product_price_eth.toExponential(2)} ETH
              </p>
              <div className="flex items-center mt-4">
                <span className="text-sm text-gray-600 mr-2">Rating:</span>
                <div className="flex">
                  {product.rating.rate > 0 &&
                    [...Array(rating)].map((_, i) => (
                      <svg
                        key={i}
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-yellow-500 fill-current"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M10 2a.75.75 0 0 1 .673.418l1.882 3.815 4.21.612a.75.75 0 0 1 .416 1.279l-3.046 2.97.719 4.192a.75.75 0 0 1-1.088.791L10 14.347l-3.766 1.984a.75.75 0 0 1-1.088-.79l.72-4.193L.818 8.124a.75.75 0 0 1 .416-1.28l4.21-.612L9.327 2.418A.75.75 0 0 1 10 2zm0 3.634a.75.75 0 0 1 .672.39l1.453 2.945.032.18.657 3.839-3.44-1.811a.75.75 0 0 1-.698 0l-3.44 1.81.657-3.839.032-.18 1.453-2.945a.75.75 0 0 1 .672-.39zM10 5.31V2.5L7.575 6.61a.75.75 0 0 1-.663.39l-3.07.447 2.226 2.17a.75.75 0 0 1 .216.664l-.527 3.078 2.769-1.457a.75.75 0 0 1 .698 0l2.77 1.456-.527-3.078a.75.75 0 0 1 .216-.664l2.227-2.17-3.07-.447a.75.75 0 0 1-.663-.39L10 2.5v2.81z"
                          clipRule="evenodd"
                        />
                      </svg>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Do you want to purchase this product?
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <p className="font-semibold text-base">Price: ${product.price}</p>
              <p>
                This action cannot be undone. This will purchase this product on
                the mentioned price.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={purchaseProduct}>
              Continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Product;
