"use client";
import { contract } from "@/thirdweb";
import { ethers, toBigInt } from "ethers";
import { useState } from "react";
import { prepareContractCall, resolveMethod, toEther, toWei } from "thirdweb";
import {
  useConnect,
  useConnectedWallets,
  useReadContract,
  useSendTransaction,
} from "thirdweb/react";
import hero from "@/public/hero.jpg";
import Image from "next/image";
import axios from "axios";
import { PRODUCT } from "@/app/page";

export default function Purchase() {
  const ETH_USD: number = 3400;
  const [productId, setProductId] = useState<number | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const wallets = useConnectedWallets();
  const { mutate: sendTransaction, isPending } = useSendTransaction();
  // const { data, isLoading } = useReadContract({
  //   contract,
  //   method: "setProductPrice",
  // });
  const purchaseProduct = async () => {
    if (wallets.length === 0) {
      alert("Please connect wallet");
    } else {
      try {
        setLoading(true);
        const productData: PRODUCT | null = (
          await axios.get(`https://fakestoreapi.com/products/${productId}`)
        ).data;
        if (productData) {
          const product_price_in_eth: number = productData.price / ETH_USD;
          const product_price_in_wei = toWei(product_price_in_eth.toString());
          const transaction = prepareContractCall({
            contract,
            method: resolveMethod("purchaseProduct"),
            params: [productId],
            value: product_price_in_wei,
          });
          const tx = sendTransaction(transaction);
          alert(
            "Product purchase successfully. Wait for the transaction confirmation."
          );
        } else {
          alert("Product not found!");
        }
        setLoading(false);
      } catch (error) {
        setLoading(false);
        alert("Error booking ground: " + String(error));
      }
    }
  };

  return (
    <div className="relative">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src={hero}
          alt="Banner Image"
          className="absolute inset-0 w-full h-full object-cover"
          width={1920}
          height={1500}
        />
        <div className="absolute inset-0 bg-black opacity-50"></div>
      </div>

      {/* Content */}
      <div className="container mx-auto relative z-10 py-24">
        <h1 className="text-3xl font-bold my-8 text-center text-white">
          Purchase Product
        </h1>
        <div className="max-w-md mx-auto bg-white shadow-md rounded-lg overflow-hidden">
          <div className="p-4">
            <input
              type="text"
              placeholder="Enter product id"
              value={productId}
              onChange={(e) => setProductId(Number(e.target.value))}
              className="border p-2 w-full mb-4"
            />
            <button
              onClick={purchaseProduct}
              disabled={loading || !productId}
              className={`w-full bg-blue-500 text-white px-4 py-2 rounded ${
                loading && "opacity-50 cursor-not-allowed"
              } ${!productId && "opacity-50 cursor-not-allowed"}`}
            >
              {loading ? "Purchasing..." : "Purchase"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
