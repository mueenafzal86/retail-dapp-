/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains:["media.api-sports.io", "fakestoreapi.com"]
    }
};

export default nextConfig;
