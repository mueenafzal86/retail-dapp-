import { createThirdwebClient, getContract } from "thirdweb";
import { contract_abi, contract_address } from "./contract";
import { sepolia } from "thirdweb/chains";

export const client = createThirdwebClient({
  clientId: "628fbb61075a9f7fb935689b4d734460",
});

const myChain = sepolia;

export const contract = getContract({
  address: contract_address,
  chain: myChain,
  client,
  abi: contract_abi,
});
